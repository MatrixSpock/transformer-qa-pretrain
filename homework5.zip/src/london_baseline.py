# TODO: [part d]
# Calculate the accuracy of a baseline that simply predicts "London" for every
#   example in the dev set.
# Hint: Make use of existing code.
# Your solution here should only be a few lines.

import argparse
import utils

def main():
    accuracy = 0.0

    # Compute accuracy in the range [0.0, 100.0]
    ### YOUR CODE HERE ###
    # Create a list of "London" predictions for each example in the dev set
    with open("birth_dev.tsv", encoding='utf-8') as f:
        lines = [x.strip().split('\t') for x in f]
    
    # Count the number of examples
    total = len(lines)
    
    # Create a list of "London" predictions for each example
    predictions = ["London"] * total
    
    # Calculate accuracy using the evaluate_places function
    total, correct = utils.evaluate_places("birth_dev.tsv", predictions)
    
    # Convert to percentage
    accuracy = (correct / total) * 100.0
    ### END YOUR CODE ###

    return accuracy

if __name__ == '__main__':
    accuracy = main()
    with open("london_baseline_accuracy.txt", "w", encoding="utf-8") as f:
        f.write(f"{accuracy}\n")
